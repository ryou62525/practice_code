#pragma once
#include "utility.h"

enum Window 
{
	WIDTH = 512,
	HEIGHT = 512
};

class App
{
public:

	static AppEnv& Get()
	{
		static AppEnv env(Window::WIDTH, Window::HEIGHT, false, false);
		return env;
	}
};