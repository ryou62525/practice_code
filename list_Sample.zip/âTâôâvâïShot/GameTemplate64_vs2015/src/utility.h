#pragma once
#include "lib/framework.hpp"

struct Transform
{
	Vec2f pos = Vec2f(0, 0);
	Vec2f size = Vec2f::Zero();
	Vec2f rotate = Vec2f(0, 0);
	Vec2f scale = Vec2f::Ones();
};