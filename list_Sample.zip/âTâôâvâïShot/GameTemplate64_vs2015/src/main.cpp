﻿
#include "app.h"
#include "player.h"
 
int main() {
  
	App::Get();

	Player player;

  while (App::Get().isOpen()) {
	  
	  player.Update();

	  App::Get().begin();

	  player.Draw();

	  App::Get().end();
  }
}
