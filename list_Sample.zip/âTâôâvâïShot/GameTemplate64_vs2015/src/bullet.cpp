#include "bullet.h"

Bullet::Bullet(Vec2f pos)
{
	transform.pos = pos;
	transform.size = Vec2f(5, 5);
	speed = 7.0f;
	isActive = true;
	eraseCount = 50;
}

void Bullet::Update()
{
	eraseCount -= 1;	
	transform.pos.y() += speed;

	//eraseCount�̃J�E���g�������炵�O�ɂȂ�����isActive��false�ɂ���
	if (eraseCount <= 0)
	{
		isActive = false;
	}
}

void Bullet::Draw()
{
	drawFillCircle(transform.pos.x(), transform.pos.y(), transform.size.x(), transform.size.y(), 50, Color::blue);
}
