#pragma once
#include "app.h"
#include "bullet.h"
#include <list>

class Player
{
	Transform transform, bulletTransform;
	float speed;

	std::list<Bullet> bulletList;	//Bullet��list�z��Ƃ��Ďg�����߂̐錾

public:

	Player();

	void Update();
	void Draw();

};